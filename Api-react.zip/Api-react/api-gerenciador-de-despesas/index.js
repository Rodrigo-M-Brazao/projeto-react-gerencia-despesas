const express = require('express');
const financasService = require('./services/financasServices');
const userService = require('./services/usersServices');
const body = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');

//crio um objeto app para receber todas as funções
//do express
const app = express();
//usamos o cors para evitar alguns erros padroes que existem
app.use(cors());
//usamos o body.json para habilitar o uso de json na nossa api 
//(com isso podemos receber e ler json no corpo)
app.use(body.json());

// CRUD Finanças

app.get('/financials/:nome', (req, res) => {
    const {nome} = req.params;

    // Leia todas as finanças do arquivo JSON
    const financas = financasService.buscarFinancas(nome);
    if(financas){
        res.status(200).send(financas)
    } else {
        res.status(404).send('recurso não encontrado');
    }

});

app.post('/financials', (req, res) => {
    const { descricao, valor, importancia, nomeUsuario } = req.body;
    if (descricao && valor && importancia && nomeUsuario) {
        const novaFinanca = { descricao, valor, importancia, nomeUsuario };
        financasService.addFinanca(novaFinanca);
        res.status(201).send("Finança adicionada");
    } else {
        res.status(400).send('Dados inválidos');
    }
});

app.delete('/financials', (req, res) => {
    const financaToDelete = req.body; 

    financasService.deleteFinanca(financaToDelete);

    res.send('Finança excluída com sucesso');
});

// Rota para atualizar uma finança
app.put('/financials', (req, res) => {
    const { target, newData } = req.body;
    
    // Verifica se os dados necessários estão presentes
    if (target && newData) {
        financasService.updateFinanca(target, newData);
        res.status(200).send('Finança atualizada com sucesso');
    } else {
        res.status(400).send('Dados inválidos');
    }
});

// CRUD usuário

app.post('/addUser', (req, res)=>{
    //extrair os dados do corpo da requisição
    const {name, password} = req.body;
    //se os dados existirem
    if(name && password){
        //add eles junto com a função addUser
        userService.addUser(name, password);
        res.status(200).send("User add")
    } else {
        res.status(400).send('Dados invalidos')
    }
})

//rota de login
app.post('/login', async (req, res)=>{
    //Extração das variáveis que estão sendo passadas
    const {name, password} = req.body;

    //aguardamos o resultado da função que irá validar nossos dados
    const result = await userService.validateLogin(name, password);
    const token = jwt.sign({  name: result.name }, 'your_jwt_secret', { expiresIn: '1h' });
    
    if(result){
        res.status(200).json({ token, name });
        // res.status(200).json('ok')
    } else {
        res.status(401).json('Dados incorretos')
    }

})

//definimos o endereço das rotas, no caso, a porta
app.listen(8080)