const fs = require('fs'); //isso permite que possamos ler e/ou escrever no json


//Rota responsável por add um novo usuário na nossa lista
exports.addUser = (name, password) => {
    //lemos os dados que estão no json users
    const dadosDoJson = fs.readFileSync('users.json', 'utf-8');
    // const tokenJson = fs.readFileSync('usersAuth.json', 'utf-8');
    //converte pro formato que queremos trabalhar
    const users = JSON.parse(dadosDoJson);
    //criamos o novo usuário passando um objeto pra ele com os dados 
    //dos parâmetros
    const novoUsuario = {name: name, password: password};
    //inserimos esse novo usuário dentro da lista através do push
    users.push(novoUsuario);
    //escrevemos essa nova lista no nosso json através do fs.write
    fs.writeFileSync('users.json', JSON.stringify(users), 'utf-8')
}

exports.validateLogin = (name, password) => {
    //criamos uma constante que recebe os dados do json
    const userData = JSON.parse(fs.readFileSync('users.json', 'utf-8'));

    //constante que recebe o primeiro valor encontrado com base na regra
    const user = userData.find(user => user.name === name );
    

    //valida o usuário e a senha, sendo que caso o user não existir ou a senha
    //estiver incorreta, retornamos false
    if(!user || user.password !== password){
        return false;
    }
    return true;
    
}