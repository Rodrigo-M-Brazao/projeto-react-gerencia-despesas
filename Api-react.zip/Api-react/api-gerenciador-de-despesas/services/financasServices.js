//biblioteca para ler arquivos
const fs = require('fs');

const financialsFilePath = './financials.json';

const minhasFinancas = fs.readFileSync(financialsFilePath, 'utf-8');



exports.buscarFinancas = (nome) => {
    const financas = JSON.parse(minhasFinancas);
    return financas.filter(financa => financa.nomeUsuario.toLowerCase().includes(nome.toLowerCase()));
}

exports.addFinanca = (financa) => {
    const financas = JSON.parse(minhasFinancas);
    financas.push(financa);
    fs.writeFileSync('financials.json', JSON.stringify(financas), 'utf-8');
};
exports.deleteFinanca = (financaToDelete) => {
    const financas = JSON.parse(minhasFinancas);
    const updatedFinancas = financas.filter(financa => {
        // Verifica se as informações da finança correspondem à que deve ser excluída
        return !(
            financa.descricao === financaToDelete.descricao &&
            financa.importancia === financaToDelete.importancia &&
            financa.valor === financaToDelete.valor
        );
    });

    fs.writeFileSync('financials.json', JSON.stringify(updatedFinancas), 'utf-8');
};

// Função para atualizar uma finança
exports.updateFinanca = (target, newData) => {
    const financas = JSON.parse(minhasFinancas);
    const updatedFinancas = financas.map(financa => {
        // Verifica se as informações da finança correspondem ao alvo
        if (
            financa.descricao === target.descricao &&
            financa.importancia === target.importancia &&
            financa.valor === target.valor
        ) {
            // Atualiza as informações com os novos dados
            return { ...financa, ...newData };
        }
        return financa;
    });

    fs.writeFileSync(financialsFilePath, JSON.stringify(updatedFinancas), 'utf-8');
};